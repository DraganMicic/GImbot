> ![MikroE](http://www.mikroe.com/img/designs/beta/logo_small.png)
> #Line Follower Click#
> ##By [MikroElektronika](http://www.mikroe.com)
---

## Installation
Use the package manager to install the library for your architecture.

###Example
```
#include "line_follower_buggy_api.h"
#include "resources.h"
#include "arrows.h"

// Line Follower pins
sbit LINE_FOLLOWER_U1 at GPIOC_IDR.B2;
sbit LINE_FOLLOWER_U2 at GPIOA_IDR.B4;
sbit LINE_FOLLOWER_U3 at GPIOD_IDR.B8;
sbit LINE_FOLLOWER_U4 at GPIOD_IDR.B9;
sbit LINE_FOLLOWER_U5 at GPIOA_IDR.B0;

// TFT pins
unsigned int TFT_DataPort at GPIOE_ODR;
sbit TFT_RST at GPIOE_ODR.B8;
sbit TFT_RS at GPIOE_ODR.B12;
sbit TFT_CS at GPIOE_ODR.B15;
sbit TFT_RD at GPIOE_ODR.B10;
sbit TFT_WR at GPIOE_ODR.B11;
sbit TFT_BLED at GPIOE_ODR.B9;

void display_init()
{
    TFT_Init_ILI9341_8bit( 320, 240 );
    TFT_BLED = 1;
    TFT_Set_Pen( CL_WHITE, 1 );
    TFT_Set_Brush( 1,CL_WHITE,0,0,0,0 );
    TFT_Set_Font( TFT_defaultFont, CL_BLACK, FO_HORIZONTAL );
    TFT_Fill_Screen( CL_WHITE );
    TFT_Set_Pen( CL_Black, 1 );
    TFT_Line( 20, 220, 300, 220 );
    TFT_LIne( 20,  46, 300,  46 );
    TFT_Set_Font( &HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL );
    TFT_Write_Text( "Line Follower Click", 85, 14 );
    TFT_Set_Font( &Verdana12x13_Regular, CL_BLACK, FO_HORIZONTAL );
    TFT_Write_Text("EasyMx PRO v7 for STM32", 19, 223);
    TFT_Set_Font( &Verdana12x13_Regular, CL_RED, FO_HORIZONTAL );
    TFT_Write_Text( "www.mikroe.com", 200, 223 );
    TFT_Set_Font( &HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL );
}

void system_init()
{
    GPIO_Digital_Input( &GPIOC_BASE, _GPIO_PINMASK_2 );
    GPIO_Digital_Input( &GPIOA_BASE, _GPIO_PINMASK_4 );
    GPIO_Digital_Input( &GPIOD_BASE, _GPIO_PINMASK_8 );
    GPIO_Digital_Input( &GPIOD_BASE, _GPIO_PINMASK_9 );
    GPIO_Digital_Input( &GPIOA_BASE, _GPIO_PINMASK_0 );
}

void display_dir( turn_control_t direction)
{
    TFT_Set_Pen(CL_WHITE, 1);
    TFT_Rectangle( 20, 90, 100, 150 );
    TFT_Rectangle( 220, 90, 300, 150 );
}

void display_speed( speed_control_t speed )
{
    TFT_Set_Pen(CL_WHITE, 1);
    TFT_Rectangle( 100, 90, 300, 150 );
}

// Callback function
void control_buggy( buggy_control_t *ctl )
{
     TFT_Set_Pen(CL_WHITE, 1);
     TFT_Rectangle( 20, 90, 300, 150 );

     if ( !ctl->status )
     {
         if ( ctl->speed == 0 )
         {
             TFT_Set_Font( &HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL );
             TFT_Write_Text( "STOP", 130, 120 );
         } else if ( ctl->speed == 1 ) {
             TFT_Set_Font( &HandelGothic_BT21x22_Regular, CL_GREEN, FO_HORIZONTAL );
             TFT_Write_Text( "START", 120, 120 );
         } else if ( ctl->speed == 2 ) {
             TFT_Set_Font( &HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL );
             TFT_Write_Text( "BRAKE", 120, 120 );
         } else if ( ctl->speed == 3 ) {
             TFT_Set_Font( &HandelGothic_BT21x22_Regular, CL_BLUE, FO_HORIZONTAL );
             TFT_Write_Text( "ACCELERATE", 100, 120 );
         } else {
             TFT_Set_Font( &HandelGothic_BT21x22_Regular, CL_BLACK, FO_HORIZONTAL );
             TFT_Write_Text( "CONSTANT", 110, 120 );
         }
     } else {
         
         TFT_Set_Pen(CL_WHITE, 1);
         TFT_Rectangle( 20, 90, 300, 150 );
         TFT_Set_Font( &HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL );
         TFT_Write_Text( "TRACK LOST", 100, 120 );
     }
     
     if ( ctl->direction )
     {
         if ( ctl->direction == 1 )
         {
             TFT_Image( 20, 105, arrow_left_01_bmp, 1 );
         
         } else if ( ctl->direction == 2 ) {
         
             TFT_Image( 20, 105, arrow_left_02_bmp, 1 );
             
         } else if ( ctl->direction == 3 ) {
         
             TFT_Image( 20, 105, arrow_left_03_bmp, 1 );
         
         } else if ( ctl->direction == 4 ) {
         
             TFT_Image( 20, 105, arrow_left_03_bmp, 1 );
         
         } else if ( ctl->direction == 11 ) {
         
             TFT_Image( 250, 105, arrow_right_01_bmp, 1 );
         
         } else if ( ctl->direction == 12 ) {
         
             TFT_Image( 250, 105, arrow_right_02_bmp, 1 );
         
         } else if ( ctl->direction == 13 ) {
         
             TFT_Image( 250, 105, arrow_right_03_bmp, 1 );
         
         } else if ( ctl->direction == 14 ) {

             TFT_Image( 250, 105, arrow_right_03_bmp, 1 );
         }
     }
}

void main() 
{
     system_init();
     display_init();
     line_follower_api_init( control_buggy );

     while( 1 )
     {
         line_follower_process();
         Delay_ms( 400 );
     }
}
```
